function doGet(e) {
  return handleFormSubmission(e);
}

function doPost(e) {
  return handleFormSubmission(e);
}

function handleFormSubmission(e) {
  try {
    // Log the request for debugging
    Logger.log('Request received. Parameters: ' + JSON.stringify(e.parameter));
    
    const scriptProperties = PropertiesService.getScriptProperties();
    const spreadsheetId = scriptProperties.getProperty('SPREADSHEET_ID');
    
    Logger.log('Spreadsheet ID from properties: ' + spreadsheetId);
    
    if (!spreadsheetId || spreadsheetId === '' || spreadsheetId === 'YOUR_SPREADSHEET_ID_HERE') {
      Logger.log('ERROR: Spreadsheet ID not configured');
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'Spreadsheet ID not configured. Run setupSpreadsheetId() first.'
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Open the spreadsheet
    let spreadsheet;
    try {
      spreadsheet = SpreadsheetApp.openById(spreadsheetId);
      Logger.log('Spreadsheet opened successfully');
    } catch (error) {
      Logger.log('ERROR opening spreadsheet: ' + error.toString());
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'Cannot open spreadsheet. Check ID: ' + spreadsheetId
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Get or create "Responses" sheet
    let sheet = spreadsheet.getSheetByName('Responses');
    if (!sheet) {
      Logger.log('Creating new Responses sheet');
      sheet = spreadsheet.insertSheet('Responses');
      // Add headers with bold formatting
      sheet.appendRow(['Timestamp', 'Name', 'Email', 'Phone']);
      const headerRange = sheet.getRange(1, 1, 1, 4);
      headerRange.setFontWeight('bold');
      headerRange.setBackground('#e8e8e8');
    }
    
    // Get form data from query parameters
    const params = e.parameter;
    const name = params.name ? String(params.name).trim() : '';
    const email = params.email ? String(params.email).trim() : '';
    const phone = params.phone ? String(params.phone).trim() : '';
    
    Logger.log('Form data - Name: ' + name + ', Email: ' + email + ', Phone: ' + phone);
    
    // Validate that at least one field is filled
    if (!name && !email && !phone) {
      Logger.log('ERROR: No data received');
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'No data received'
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Append row with timestamp
    const timestamp = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    
    sheet.appendRow([timestamp, name, email, phone]);
    Logger.log('Row appended successfully. Timestamp: ' + timestamp);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'Data saved successfully',
      data: { timestamp: timestamp, name: name, email: email, phone: phone }
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    Logger.log('CATCH ERROR: ' + error.toString());
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: 'Error: ' + error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// Helper function to setup - run this once to store your spreadsheet ID
function setupSpreadsheetId() {
  // ⚠️ IMPORTANT: Replace 'YOUR_SPREADSHEET_ID_HERE' with your actual Google Sheet ID
  // Get it from: https://docs.google.com/spreadsheets/d/XXXXX/edit
  const spreadsheetId = 'YOUR_SPREADSHEET_ID_HERE';
  
  if (spreadsheetId === 'YOUR_SPREADSHEET_ID_HERE') {
    Logger.log('ERROR: You must replace YOUR_SPREADSHEET_ID_HERE with your actual Sheet ID');
    return;
  }
  
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', spreadsheetId);
  Logger.log('✅ Spreadsheet ID saved successfully: ' + spreadsheetId);
}

// Verification function - run this to test if everything is set up
function verifySetup() {
  Logger.log('=== VERIFICATION REPORT ===');
  
  const scriptProperties = PropertiesService.getScriptProperties();
  const savedId = scriptProperties.getProperty('SPREADSHEET_ID');
  
  Logger.log('1. Saved Spreadsheet ID: ' + (savedId || 'NOT SET'));
  
  if (!savedId || savedId === 'YOUR_SPREADSHEET_ID_HERE') {
    Logger.log('❌ PROBLEM: Spreadsheet ID not configured');
    Logger.log('   FIX: Edit setupSpreadsheetId() function and replace YOUR_SPREADSHEET_ID_HERE');
    return;
  }
  
  try {
    const sheet = SpreadsheetApp.openById(savedId);
    Logger.log('✅ Spreadsheet can be opened');
    
    let responseSheet = sheet.getSheetByName('Responses');
    if (responseSheet) {
      Logger.log('✅ Responses sheet exists');
      Logger.log('   Current rows: ' + responseSheet.getLastRow());
    } else {
      Logger.log('⚠️  Responses sheet does not exist (will be created on first submission)');
    }
  } catch (error) {
    Logger.log('❌ PROBLEM: Cannot open spreadsheet');
    Logger.log('   Error: ' + error.toString());
    Logger.log('   Check if ID is correct: ' + savedId);
  }
}
